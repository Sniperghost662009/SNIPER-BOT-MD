//creado por https://github.com/DIEGO-OFC


/*import { randomBytes } from 'crypto'

let handler = async (m, { conn, text }) => {
  let chats = Object.entries(conn.chats).filter(([jid, chat]) => !jid.endsWith('@g.us') && chat.isChats).map(v => v[0])
  let cc = conn.serializeM(text ? m : m.quoted ? await m.getQuotedObj() : false || m)
  let teks = text ? text : cc.text
  conn.reply(m.chat, `*[❕] 𝙼𝙴𝙽𝚂𝙰𝙹𝙴 𝙴𝙽𝚅𝙸𝙰𝙳𝙾 𝙰 ${chats.length} 𝙲𝙷𝙰𝚃𝚂 𝙿𝚁𝙸𝚅𝙰𝙳𝙾𝚂*`, m)
  for (let id of chats) await conn.copyNForward(id, conn.cMod(m.chat, cc, /bc|broadcast/i.test(teks) ? teks : teks + '\n' + readMore + '「 ' + author + ' All Chat Broadcast 」\n' + randomID(32)), true).catch(_ => _)}

handler.help = ['broadcastchats', 'bcchats'].map(v => v + ' <teks>')
handler.tags = ['owner']
handler.command = /^(broadcastchats?|bcc(hats?)?)$/i

handler.owner = true

export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

const randomID = length => randomBytes(Math.ceil(length * .5)).toString('hex').slice(0, length)*/

const _0xcb0928=_0x73f5;function _0x73f5(_0x2fb28e,_0x116562){const _0x493f39=_0x493f();return _0x73f5=function(_0x73f571,_0x3274d8){_0x73f571=_0x73f571-0x153;let _0x232f0b=_0x493f39[_0x73f571];return _0x232f0b;},_0x73f5(_0x2fb28e,_0x116562);}(function(_0x4aef13,_0x590dcf){const _0x325bb6=_0x73f5,_0x428ac7=_0x4aef13();while(!![]){try{const _0x527179=-parseInt(_0x325bb6(0x15a))/0x1*(parseInt(_0x325bb6(0x157))/0x2)+-parseInt(_0x325bb6(0x167))/0x3+parseInt(_0x325bb6(0x159))/0x4+parseInt(_0x325bb6(0x15d))/0x5*(parseInt(_0x325bb6(0x163))/0x6)+-parseInt(_0x325bb6(0x16c))/0x7*(-parseInt(_0x325bb6(0x165))/0x8)+-parseInt(_0x325bb6(0x169))/0x9*(parseInt(_0x325bb6(0x15c))/0xa)+parseInt(_0x325bb6(0x15e))/0xb;if(_0x527179===_0x590dcf)break;else _0x428ac7['push'](_0x428ac7['shift']());}catch(_0x4df540){_0x428ac7['push'](_0x428ac7['shift']());}}}(_0x493f,0xbc471));let handler=async(_0x1fd711,{conn:_0x553326,text:_0x29f4c8})=>{const _0x3fc6fa=_0x73f5;let _0x1aa9d0=Object[_0x3fc6fa(0x16b)](await _0x553326['chats']);_0x553326[_0x3fc6fa(0x168)](_0x1fd711['chat'],_0x3fc6fa(0x15b)+_0x1aa9d0['length']+_0x3fc6fa(0x160),_0x1fd711);for(let _0x495b04 of _0x1aa9d0){let _0x534e12=_0x3fc6fa(0x153);await _0x553326[_0x3fc6fa(0x154)](_0x495b04,_0x29f4c8,wm,_0x534e12,[['𝙼𝙴𝙽𝚄',_0x3fc6fa(0x170)]],_0x1fd711);}_0x1fd711[_0x3fc6fa(0x168)](_0x3fc6fa(0x161));};handler[_0xcb0928(0x15f)]=[_0xcb0928(0x171),_0xcb0928(0x162)][_0xcb0928(0x16f)](_0x4cd549=>_0x4cd549+'\x20<teks>'),handler[_0xcb0928(0x164)]=[_0xcb0928(0x16d)],handler['command']=/^(broadcastchats?|bcc(hats?)?)$/i,handler[_0xcb0928(0x16d)]=!![],handler[_0xcb0928(0x166)]=![],handler[_0xcb0928(0x156)]=![],handler[_0xcb0928(0x16a)]=![],handler[_0xcb0928(0x158)]=![],handler[_0xcb0928(0x16e)]=![],handler[_0xcb0928(0x172)]=![],handler[_0xcb0928(0x155)]=null;function _0x493f(){const _0x6a63f2=['1851597wtqLwc','reply','4907043tgTcbm','group','keys','21BCitSr','owner','admin','map','#menusimple','broadcastchats','botAdmin','./Menu2.jpg','sendButton','fail','premium','192692ppFLwl','private','1055836urmsbN','5DZOWIC','*[❕]_Mensaje\x20enviado\x20a\x20','20hqgCWZ','295DXsttZ','10726518bJnETJ','help','\x20chats_*','*✅*','bcchats','61206FTytDu','tags','2985632owFVIS','mods'];_0x493f=function(){return _0x6a63f2;};return _0x493f();}export default handler;
